# Discover the Real London

A simple static HTML/CSS website for the school travel-guide project.

## Run it
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub account.
2. Create a new public repository, for example `discover-real-london`.
3. Upload `index.html` and `style.css`.
4. Open Settings → Pages.
5. Under Source, choose "Deploy from a branch".
6. Select the `main` branch and `/root`, then Save.
7. GitHub will give you a public website link.

The website uses two Unsplash image URLs and Google Fonts. If your school requires locally stored images, download suitable copyright-safe images and replace the background URLs in `style.css`.
